import { StyleSheet, StatusBar, Dimensions } from 'react-native';


export default styles;